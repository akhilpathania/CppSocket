#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include<iostream>
using namespace std;

int PORT;

int main(int argv , char **argc)
{
    if(argv < 2 )
    {
        perror("Ussage: Port");
        exit(0);
    }
    PORT = atoi(argc[1]);
	int clientSocket, conn_stat;
	struct sockaddr_in serverAddr;
	char buffer[1024];


	clientSocket = socket(AF_INET, SOCK_STREAM, 0);
	if(clientSocket < 0)
    {
		perror("Error in connection.\n");
		exit(1);
	}
	cout<<"Client Socket is created.\n";

	memset(&serverAddr, '\0', sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(PORT);
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	conn_stat = connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
	if(conn_stat < 0)
    {
		perror("Error in connection.\n");
		exit(1);
	}
	cout<<"Connected to Server.\n";

	while(1)
    {

        cout<<"Connected to server\n";
        cout<<"ID's Parent"<<getppid()<<"  Id Child"<<getpid()<<endl;
        cout<<"Enter Your Expression.\n>";
        string str="";
	    cin>>str;
        char *hello = &str[0u];                        
        //converting string to char*
        if(str == "exit" || str == "shut")
        {
            send(clientSocket,hello, strlen(hello), 0);
            cout<<"Disconnected from server.\n";               
            //sending exit command to server;
            close(clientSocket);
            exit(1);
        }
        send(clientSocket,hello, strlen(hello), 0);

        cout<<"\n\nWaiting for reply....\n";
		

		char server_message[256];
        int valread = read(clientSocket , server_message , 1024);                             //receiving answer of expression from server
        cout<<"val rread = "<<valread;
        if(!strcmp(server_message,"exit") || valread == 0 || valread ==-1)
        {
            cout<<"\n\nYour Seesion has been ended by server\n\n";                //session ended if server reply exit
            close(clientSocket);
            exit(0);
        }
        cout<<"\nCalculated Answer is: "<<server_message<<endl;
	}
    close(clientSocket);
	return 0;
}